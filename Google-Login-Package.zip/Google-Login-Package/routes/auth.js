
const express = require('express');
const authController = require('../controller/auth');
const router = express.Router();
const localizationMiddleware = require('../middleware/localization');


router
.get('/google/login', localizationMiddleware, authController.loginUserGoogle)
.get('/google/callback', localizationMiddleware, authController.loginUserGoogleCallback)



exports.router = router;