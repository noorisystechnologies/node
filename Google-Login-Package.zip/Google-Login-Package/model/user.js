const mongoose = require('mongoose');
const { Schema } = mongoose;


const userSchema = new Schema({
    first_name: {
                type:String, 
                // required: [true, 'first name should not be empty!'], 
            },
    last_name: String,      
    email: {
            type:String,
            unique: true,
            validate: {
                validator: function(v) {
                    return /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/.test(v);
                  },
                  message: props => `${props.value} is not a valid email!`,   
            }, 
            required: [true, 'email should not be empty!'],
        },
    password: { type: String, minLength: 6, required: true },
    token: String,
    google_id: String,
  });

  // Add middleware to handle duplicate key errors
    userSchema.post('save', function (error, doc, next) {
        if (error.name === 'MongoError' && error.code === 11000) {
            next(new Error('Email must be unique'));
        } else {
            next();
        }
    });

  exports.User = mongoose.model('User', userSchema);