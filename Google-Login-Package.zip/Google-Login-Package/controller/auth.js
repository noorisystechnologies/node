const jwt = require('jsonwebtoken');
const model = require('../model/user');
const User = model.User;
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const privateKey = fs.readFileSync(path.join(__dirname, '../private.key'));
const passport = require('passport');
const crypto = require('crypto');

// Google Login / SignUp
exports.loginUserGoogle = (req, res, next) => {
    passport.authenticate('google', { scope: ['profile', 'email'] })(req, res, next);
};

exports.loginUserGoogleCallback = (req, res, next) => {
    passport.authenticate('google', { failureRedirect: '/auth/login' })(req, res, async () => {
        try {
            console.log(req.user);
            const user = await User.findOne({ email: req.user.email });

            // Generate a random password for new users
            const randomBytes = crypto.randomBytes(6);
            const randomPassword = randomBytes.toString('hex');

            // Generate JWT token
            const token = jwt.sign({ email: req.user.email, first_name: req.user.displayName }, privateKey, { algorithm: 'RS256' });

            if (!user) {
                // Create a new user if not found
                const newUser = new User({
                    first_name: req.user.displayName,
                    last_name: "",
                    email: req.user.email,
                    // Hash the random password before saving
                    password: bcrypt.hashSync(randomPassword, 10),
                    token: token,
                    google_id: req.user.google_id
                });

                await newUser.save();

                return res.status(201).json({
                    status: 'success',
                    message: req.t('user_registered_success'),
                    data: {
                        first_name: newUser.first_name,
                        last_name: newUser.last_name,
                        email: newUser.email,
                    },
                    token: token,
                });
            }

            // Return success response if user exists
            return res.status(200).json({
                status: 'success',
                message: req.t('login_success'),
                data: {
                    first_name: user.first_name,
                    last_name: user.last_name,
                    email: user.email,
                },
                token: token,
            });
        } catch (error) {
            console.error('Error in loginUserGoogleCallback:', error);
            return res.status(500).json({ status: 'error', message: 'Internal Server Error' });
        }
    });
};
