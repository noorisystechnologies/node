const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const model = require('../model/user');
const User = model.User;

passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: '/auth/google/callback'
  },
  async (accessToken, refreshToken, profile, done) => {
    try {
        let user = await User.findOne({ email: profile.emails[0].value });
        if (!user) {
                user = new User({
                    google_id: profile.id,
                    displayName: profile.displayName,
                    first_name: profile.name.givenName,
                    last_name: profile.name.familyName,
                    email: profile.emails[0].value,
                    image: profile.photos[0].value,
                });
        } else {

            user.google_id = profile.id;
        }

        await User.findOneAndUpdate(
            { email: profile.emails[0].value },
            { $set: { google_id: profile.id } },
            { new: true }
        );
        return done(null, user);

    } catch (error) {
        return done(error);
    }
}));


// Serialize and deserialize user for session management
passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
    try {
        const user = await User.findById(id);
        done(null, user);
    } catch (error) {
        done(error);
    }
});