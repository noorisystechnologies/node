In this project we simply use the passport google Strategy. Passport is authentication middleware for Node.js. Extremely flexible and modular, Passport can be unobtrusively dropped in to any Express-based web application. A comprehensive set of strategies support authentication using a username and password, Facebook, Twitter, and more. reference Before we get start assume that you have a good knowledge of JavaScript and Nodejs. so without any further delay lets start

Google Credentials:
   First we have to get Google credentials . To get credentials 'if don’t already have them ' go to Google developer Console

1) Create a new project

2) Select the project and click credentials and the select OAuth client ID

3) Now Select Web Application in application type.

4) Input your app name or whatever else you like , in Authorized JavaScript origins add this linehttp://localhost:3000  and in Authorized redirect URIs field add this line http://localhost:3000/auth/google/callback and the click to create.

5) Now copy your Google client ID and Google client secret.

Lets Initialize the New Project:
    To initialize the new project you just need to create a new folder "App name" and open folder in visual studio (or any other IDE ) code or any other IDE and run the below code in command line

npm init  
Just fill the project name and any other detail or just skip. After the package.json file is generated .

Install Dependencies
These are the Dependencies we need to install for our project.

express
connect-mongo
dotenv
express-session
mongoose
passport
passport-google-oauth20

In this project we are using some extra libraries for multilingual, hashing password and jsonwebtoken below
bcrypt - Installs bcrypt, a library used for hashing passwords securely in Node.js.
cors - Installs cors, a middleware for Express that enables Cross-Origin Resource Sharing (CORS).
i18next - Installs i18next, a popular internationalization framework for JavaScript applications.
i18next-fs-backend - Installs i18next-fs-backend, a file system backend for i18next to load translations from JSON files.
i18next-http-middleware - Installs i18next-http-middleware, a middleware for i18next to handle translations in Express.js applications.
jsonwebtoken - Installs jsonwebtoken, a library for creating and verifying JSON Web Tokens (JWT) used for authentication.
path - Installs path, a core module in Node.js used for handling file paths.
session - Installs session, a middleware for Express.js that enables session management.
express-session - Installs express-session, an Express.js middleware for session management.
dotenv - Installs dotenv, a module used for loading environment variables from a .env file into process.env.


Install Dependencies by write the below code in your terminal

npm i connect-mongo dotenv express-session mongoose passport passport-google-oauth20 bcrypt cors i18next i18next-fs-backend i18next-http-middleware jsonwebtoken path session express-session dotenv
Setup App for run
To start the server automatically we just need to install Nodemon which restart server automatically when any change is detected

npm i -D nodemon
Setup application for developer run and normal run. Just change the Script section with the below code in package.json.

"scripts": {
    "start": "node app.js",
    "dev": "nodemon app.js"
  },
Start local server
To start our app for testing/developer just simply type the following command in the command line:

npm run dev
The main work is start from there
You need to just put your google client id and secret in this file. And also the mongodb uri like(mongodb://localhost:27017/) if you are hosting mongodb from your system . if you are using Mongodb Atlas it like(mongodb+srv://XXXX:XXXX@cluster0.obaan.mongodb.net/{DBNAME}?retryWrites=true&w=majority)

file:.env

PORT = 3000
MONGO_URI=mongodb+srv://XXXX:XXXX@cluster0.obaan.mongodb.net/{DBNAME}?retryWrites=true&w=majority
GOOGLE_CLIENT_ID = XXXXXXXXXX
GOOGLE_CLIENT_SECRET = XXXXXXXXXXXXXXXX
In my case we use Mongodb Atlas . you can refer this for getting mongodb atlas URI . and refer this for Google client id and secret if any problem occur .

Application
Its time code our app.js file this is the main file and it will sit in the root of our website. In this file we have to setup our server.

file:app.js

Import all the necessary modules.

require('dotenv').config();
const express = require('express');
const cors = require('cors');
const mongoose=require('mongoose');
const passport = require('passport')
const session = require('express-session')
const connectDatabase = require('./config/database');
require('./config/passport')(passport)
Connect to mongodb and set express template.

var app=express();
const PORT = process.env.PORT||3000;
dotenv.config({ path: './config/config.env' })

mongoose.connect(process.env.MONGO_URI,{
    useNewUrlParser:true,
    useUnifiedTopology: true
})
app.use(express.static('public'))
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

Initialize middleware and setup database for storing sessions.

app.use(express.urlencoded({extended:true}))
app.use(
    session({
      secret: 'keyboard cat',
      resave: false,
      saveUninitialized: false,
    })
  )
  // Passport middleware
app.use(passport.initialize())
app.use(passport.session())
last part import routes

app.use('/auth', authRouter.router);

app.listen(process.env.PORT);
Now our app.js file is ready🎉🎉

Routes
Now its time to code our routes we are to code 2 routes files oneauth.js for authentication and another one index.js for redirecting between pages Lets code out auth.js file .

file:auth.js

//Importing required modules 
onst express = require('express');
const authController = require('../controller/auth');
const router = express.Router();
const localizationMiddleware = require('../middleware/localization');
send to google to do the authentication. In scopes profile gets us their basic information including their name and email gets their emails.

router.get('/google', passport.authenticate('google', { scope: ['profile','email'] }))
Callback after google has authenticated the user.

router
.get('/google/login', localizationMiddleware, authController.loginUserGoogle)
.get('/google/callback', localizationMiddleware, authController.loginUserGoogleCallback)

exports.router = router;
Now our auth.js file is ready🎉🎉

Before creating index.js file we have to create out middleware for multilingual and also create out controller file.
file:controller/auth.js

requires to include
const jwt = require('jsonwebtoken');
const model = require('../model/user');
const User = model.User;
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const privateKey = fs.readFileSync(path.join(__dirname, '../private.key'));
const passport = require('passport');
const crypto = require('crypto');

and create a google login controller and callback function.
now ready for use controller.

Configure Passport's Google startegy
file:config/passport.js

// import all the things we need  
const GoogleStrategy = require('passport-google-oauth20').Strategy
const mongoose = require('mongoose')
const User = require('../models/User')

module.exports = function (passport) {
  passport.use(
    new GoogleStrategy(
      {
        clientID: process.env.GOOGLE_CLIENT_ID,
        clientSecret: process.env.GOOGLE_CLIENT_SECRET,
        callbackURL: '/auth/google/callback',
      },
      async (accessToken, refreshToken, profile, done) => {
        //get the user data from google 
        const newUser = {
          googleId: profile.id,
          displayName: profile.displayName,
          firstName: profile.name.givenName,
          lastName: profile.name.familyName,
          image: profile.photos[0].value,
          email: profile.emails[0].value
        }

        try {
          //find the user in our database 
          let user = await User.findOne({ googleId: profile.id })

          if (user) {
            //If user present in our database.
            done(null, user)
          } else {
            // if user is not preset in our database save user data to database.
            user = await User.create(newUser)
            done(null, user)
          }
        } catch (err) {
          console.error(err)
        }
      }
    )
  )

  // used to serialize the user for the session
  passport.serializeUser((user, done) => {
    done(null, user.id)
  })

  // used to deserialize the user
  passport.deserializeUser((id, done) => {
    User.findById(id, (err, user) => done(err, user))
  })
} 
User model
Now its time to create our database model to user user data in database.

file:models/user.js

const mongoose = require('mongoose');
const { Schema } = mongoose;


const userSchema = new Schema({
    first_name: {
                type:String, 
                // required: [true, 'first name should not be empty!'], 
            },
    last_name: String,      
    email: {
            type:String,
            unique: true,
            validate: {
                validator: function(v) {
                    return /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/.test(v);
                  },
                  message: props => `${props.value} is not a valid email!`,   
            }, 
            required: [true, 'email should not be empty!'],
        },
    password: { type: String, minLength: 6, required: true },
    token: String,
    google_id: String,
  });

  // Add middleware to handle duplicate key errors
    userSchema.post('save', function (error, doc, next) {
        if (error.name === 'MongoError' && error.code === 11000) {
            next(new Error('Email must be unique'));
        } else {
            next();
        }
    });

exports.User = mongoose.model('User', userSchema);