require('dotenv').config();

const express = require('express');
const app = express();
const cors = require('cors');

// Db Connection
const connectDatabase = require('./config/database');
connectDatabase();

const authRouter = require('./routes/auth');
const passportService = require('./config/passport');
const session = require('express-session');
const passport = require('passport');

app.use(cors());      
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(session({
    secret: 'Google client secret',
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());


app.use('/auth', authRouter.router);


app.listen(process.env.PORT);